// miniprogram/pages/isMe/isMe.js
Page({
  data: {
    userName: "", //用户名
    headImg: "",
    home: "", //家庭地址
    qqEmail: "", //QQ邮箱
    schoolId: "", //学号
    credibility: "", //信誉分，100为一颗星
    call: "", //电话
  },

  onShow() {

    wx.showLoading({
      title: '数据加载中...',
    });

    var that = this;
    if (wx.getStorageSync('openId')) {
      const db = wx.cloud.database({ // 链接数据表
        env: "xgj1-056iz"
      });
      db.collection('user').where({ //数据查询
        _openid: wx.getStorageSync('openId').result.openid //条件
      }).get({
        success: function (res) {
          // wx.getStorageSync('res',res)
          // res.data 包含该记录的数据
          console.log(res)
          that.setData({
            userName: res.data[0].userName,
            headImg: res.data[0].headImg,
            home: res.data[0].home,
            qqEmail: res.data[0].qqEmail,
            schoolId: res.data[0].schoolId,
            credibility: res.data[0].credibility,
            call: res.data[0].call
          })
        }
      })

      if (this.data.credibility > 1000) {
        this.setData({
          credibility: 1000
        })
      }
      wx.hideLoading(); //隐藏正在加载中
    } else {
      wx.showToast({
        title: "纺院社区：您尚未登录", // 提示的内容
        icon: "none", // 图标，默认success
        image: "", // 自定义图标的本地路径，image 的优先级高于 icon
        duration: 2000, // 提示的延迟时间，默认1500
        mask: true, // 是否显示透明蒙层，防止触摸穿透
      })
      wx.hideLoading(); //隐藏正在加载中
    }
  },


  headImg() {
    if (this.data.headImg != wx.getStorageSync('userinfo').avatarUrl) {
      const db = wx.cloud.database({
        env: "xgj1-056iz"
      });
      db.collection('user').where({
        _openid: wx.getStorageSync('openId').result.openid //条件
      }).update({
        // data 字段表示需新增的 JSON 数据

        data: {
          headImg: wx.getStorageSync('userinfo').avatarUrl,
        },
      })


      wx.showModal({
        title: "修改成功", // 提示的标题
        content: "点击返回上一页", // 提示的内容
        showCancel: true, // 是否显示取消按钮，默认true
        cancelColor: "#000000", // 取消按钮的文字颜色，必须是16进制格式的颜色字符串
        confirmText: "确认", // 确认按钮的文字，最多4个字符
        confirmColor: "#576B95", // 确认按钮的文字颜色，必须是 16 进制格式的颜色字符串
        complete: function () {
          // console.log("接口调用结束的回调函数（调用成功、失败都会执行）");
          wx.navigateBack({
            delta: 1
          })
        }
      })

    } else {
      wx.showToast({
        title: "纺院社区：您的头像与微信头像一致无需修改", // 提示的内容
        icon: "none", // 图标，默认success
        image: "", // 自定义图标的本地路径，image 的优先级高于 icon
        duration: 2000, // 提示的延迟时间，默认1500
        mask: false, // 是否显示透明蒙层，防止触摸穿透
      })
    }

  }

})