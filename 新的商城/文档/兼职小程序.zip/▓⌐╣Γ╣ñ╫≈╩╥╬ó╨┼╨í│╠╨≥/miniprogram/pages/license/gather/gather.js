// miniprogram/pages/license/gather/gather.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    time: "",
    bindContent: "",
    vx: "",
    name: "",
    phone: ""
  },

  bindDateChange: function (e) { //任务截止日期更改
    this.setData({
      time: e.detail.value
    })
  },

  bindContent(e) {
    this.setData({
      bindContent: e.detail.value
    })
  },

  phone(e) {
    this.setData({
      phone: e.detail.value
    })
    if(this.data.phone.length>11){
      wx.showToast({
        title: "纺院社区：手机号不得大于11位", // 提示的内容
        icon: "none", // 图标，默认success
        image: "", // 自定义图标的本地路径，image 的优先级高于 icon
        duration: 1500, // 提示的延迟时间，默认1500
        mask: false, // 是否显示透明蒙层，防止触摸穿透
      })

      this.setData({
        phone:this.data.phone.substring(0,11)
      })
    }
  },

  name(e) {
    this.setData({
      name: e.detail.value
    })
  },

  vx(e) {
    this.setData({
      vx: e.detail.value
    })
  },

  button(e){
    if(this.data.time==""||this.data.name==""||this.data.vx==""||this.data.phone==""||this.data.bindContent==""){
      wx.showToast({
        title: "纺院社区：请勿留空", // 提示的内容
        icon: "none", // 图标，默认success
        image: "", // 自定义图标的本地路径，image 的优先级高于 icon
        duration: 1500, // 提示的延迟时间，默认1500
        mask: false, // 是否显示透明蒙层，防止触摸穿透
      })
    }else{

      wx.showLoading({
        title: '数据加载中...',
      });

      const db = wx.cloud.database({
        env: "xgj1-056iz"
      });
      db.collection('license').add({
        // data 字段表示需新增的 JSON 数据

        data: {
          // _openid: wx.getStorageSync('openId').result.openid,会自动添加，不需要自己输入
          name:this.data.name,
          phone:this.data.phone,
          vx:this.data.vx,
          time: this.data.time,
          content:this.data.bindContent
        },
        success: function (res) {
          // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
          // console.log(res)
          wx.showModal({
            title: "提交成功", // 提示的标题
            content: "感谢您对本程序的信任，祝您任务顺利", // 提示的内容
            showCancel: true, // 是否显示取消按钮，默认true
            cancelColor: "#000000", // 取消按钮的文字颜色，必须是16进制格式的颜色字符串
            confirmText: "确定", // 确认按钮的文字，最多4个字符
            confirmColor: "#576B95", // 确认按钮的文字颜色，必须是 16 进制格式的颜色字符串
            complete: function () {
              // console.log("接口调用结束的回调函数（调用成功、失败都会执行）");
              wx.reLaunch({ //保留当前页面，跳转到应用内的某个页面（最多打开5个页面，之后按钮就没有响应的）后续可以使用wx.navigateBack 可以返回;
                url: "../../hall/hall"
              })
            }
          })
        }
      })

      wx.hideLoading(); //隐藏正在加载中
    }
  }
})