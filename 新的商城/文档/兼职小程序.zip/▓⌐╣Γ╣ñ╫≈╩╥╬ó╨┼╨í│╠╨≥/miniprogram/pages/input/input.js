// miniprogram/pages/input/input.js
Page({
  data: {
    t: 0,
    time: "",
    taskTitle: "", //存储任务标题
    taskContent: "", //存储额外输入内容
    taskMoney: 10, //存储金额
    taskVx: "", //存储微信号
    userinfo: {},
    openId: {},
    money: {}, //用户个人的资金
    register: 10, //如果输入的不是数字，那么就返回，代替用户输入的内容
    list: [{
        id: 0,
        title: "线下兼职"
      },
      {
        id: 1,
        title: "线上兼职"
      }
    ]
  },

  bindDateChange: function (e) { //任务截止日期更改
    var curDate = new Date();
    var nowTime=curDate.getFullYear()+"-";
    if(curDate.getMonth()<"10"){
      nowTime+="0"+(curDate.getMonth()+1)+"-"
    }else{
      nowTime+=curDate.getMonth()+"-"
    }

    if(curDate.getDate()<"10"){
      nowTime+="0"+curDate.getDate()
    }else{
      nowTime+=curDate.getDate()
    }
    console.log(nowTime)
    console.log(e.detail.value)
    if (nowTime < e.detail.value) {
      this.setData({
        time: e.detail.value
      })
    } else {
      wx.showModal({
        title: "日期错误", // 提示的标题
        content: "日期应在当前日期的基础上+1，请重新选择日期！避免任务出错", // 提示的内容
        showCancel: true, // 是否显示取消按钮，默认true
        cancelText: "取消", // 取消按钮的文字，最多4个字符
        cancelColor: "#000000", // 取消按钮的文字颜色，必须是16进制格式的颜色字符串
        confirmText: "确定", // 确认按钮的文字，最多4个字符
        confirmColor: "#576B95", // 确认按钮的文字颜色，必须是 16 进制格式的颜色字符串
      })
      this.setData({
        time: ""
      })
    }
  },

  hoverItem(e) { //兼职类型
    console.log(e)
    this.setData({
      t: e.currentTarget.dataset.index
    })
  },

  bindTitle(e) { //标题输入时，将内容存储入变量
    this.setData({
      taskTitle: e.detail.value
    })
    // console.log(e.detail.value)
  },
  bindMoney(e) { //金额输入时，将内容存储入变量
    let value = this.validateNumber(e.detail.value);
    this.setData({
      register: value,
      taskMoney: value
    })
    // console.log(e.detail.value)
  },
  validateNumber(val) { //判断输入的金额中是否含有字符
    return val.replace(/\D/g, '')
  },
  bindVx(e) { //微信号输入时，将内容存储入变量
    this.setData({
      taskVx: e.detail.value
    })
    // console.log(e.detail.value)
  },
  bindContent(e) { //标题输入时，将内容存储入变量
    this.setData({
      taskContent: e.detail.value
    })
    // console.log(e.detail.value)
  },

  addSql() { //添加按钮
    var f = false;
    if (this.data.taskMoney < 1) {
      wx.showModal({
        title: "金额错误", // 提示的标题
        content: "不可输入小于1的金额或者非金额的字符", // 提示的内容
        showCancel: true, // 是否显示取消按钮，默认true
        cancelText: "取消", // 取消按钮的文字，最多4个字符
        cancelColor: "#000000", // 取消按钮的文字颜色，必须是16进制格式的颜色字符串
        confirmText: "确定", // 确认按钮的文字，最多4个字符
        confirmColor: "#576B95", // 确认按钮的文字颜色，必须是 16 进制格式的颜色字符串
      })
    } else if (this.data.money < this.data.taskMoney) {
      wx.showModal({
        title: "资金不足", // 提示的标题
        content: "您的余额不足，请先充值再发布任务！您的余额为：" + this.data.money, // 提示的内容
        showCancel: true, // 是否显示取消按钮，默认true
        cancelText: "取消", // 取消按钮的文字，最多4个字符
        cancelColor: "#000000", // 取消按钮的文字颜色，必须是16进制格式的颜色字符串
        confirmText: "确定", // 确认按钮的文字，最多4个字符
        confirmColor: "#576B95", // 确认按钮的文字颜色，必须是 16 进制格式的颜色字符串
      })
    } else if (this.data.taskLabel == "" || this.data.taskVx == "" || this.data.taskTitle == "" || this.data.time=="") {
      wx.showModal({
        title: "温馨提示", // 提示的标题
        content: "请勿留下空白内容！", // 提示的内容
        showCancel: true, // 是否显示取消按钮，默认true
        cancelText: "取消", // 取消按钮的文字，最多4个字符
        cancelColor: "#000000", // 取消按钮的文字颜色，必须是16进制格式的颜色字符串
        confirmText: "确定", // 确认按钮的文字，最多4个字符
        confirmColor: "#576B95", // 确认按钮的文字颜色，必须是 16 进制格式的颜色字符串
      })
    } else {
      wx.showLoading({
        title: '数据加载中...',
      });

      // 获取日期，并且转化成订单号
      var timestamp = Date.parse(new Date());
      var date = new Date(timestamp); //实例化变量date
      var str = date.getFullYear();
      if (date.getMonth() + 1 < 10) {
        str += "0" + (date.getMonth() + 1);
      } else {
        str += date.getMonth() + 1;
      }
      if (date.getDate() + 1 < 10) {
        str += "0" + (date.getDate());
      } else {
        str += date.getDate();
      }
      console.log(str);
      // 数据库提交开始
      const db = wx.cloud.database({
        env: "xgj1-056iz"
      });
      db.collection('task').add({
        // data 字段表示需新增的 JSON 数据

        data: {
          // _openid: wx.getStorageSync('openId').result.openid,会自动添加，不需要自己输入
          headImg: wx.getStorageSync('userinfo').avatarUrl,
          userName: wx.getStorageSync('userinfo').nickName,
          state: false,
          taskId: str,
          taskMoney: this.data.taskMoney,
          taskVx: this.data.taskVx,
          taskTitle: this.data.taskTitle,
          taskContent: this.data.taskContent,
          taskLabel: this.data.list[this.data.t].title,
          recommend: false,
          acceptUserOpenid: "",
          time: this.data.time
        },
        success: function (res) {
          // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
          // console.log(res)
        }
      })
      // 数据库提交结束
      f = true;
    }
    if (f) { //如果以上全部通过，那么就改变金额，扣除数据库中的钱
      const db = wx.cloud.database({
        env: "xgj1-056iz"
      });
      var money1 = parseFloat(this.data.money) - parseFloat(this.data.taskMoney);
      db.collection('user').where({
        _openid: wx.getStorageSync('openId').result.openid //条件
      }).update({
        // data 字段表示需新增的 JSON 数据
        data: {
          money: money1.toFixed(2),
        },
      })

      wx.hideLoading(); //隐藏正在加载中

      wx.showModal({
        title: "提交成功", // 提示的标题
        content: "感谢您对本程序的信任，祝您任务顺利", // 提示的内容
        showCancel: true, // 是否显示取消按钮，默认true
        cancelColor: "#000000", // 取消按钮的文字颜色，必须是16进制格式的颜色字符串
        confirmText: "确定", // 确认按钮的文字，最多4个字符
        confirmColor: "#576B95", // 确认按钮的文字颜色，必须是 16 进制格式的颜色字符串
        complete: function () {
          // console.log("接口调用结束的回调函数（调用成功、失败都会执行）");
          wx.reLaunch({ //保留当前页面，跳转到应用内的某个页面（最多打开5个页面，之后按钮就没有响应的）后续可以使用wx.navigateBack 可以返回;
            url: "../hall/hall"
          })
        }
      })
    }
  },

  onShow() {
    var that = this;
    const userinfo = wx.getStorageSync('userinfo');
    const openId = wx.getStorageSync('openId');
    this.setData({
      userinfo,
      openId
    })
    if (wx.getStorageSync('openId')) {
      //获取用户数据库的个人数据开始
      const db = wx.cloud.database({ // 链接数据表
        env: "xgj1-056iz"
      });
      db.collection('user').where({ //数据查询
        _openid: openId.result.openid //条件
      }).get({
        success: function (res) {
          // res.data 包含该记录的数据
          that.setData({
            money: res.data[0].money,
          })
        }
      })
      // 获取用户数据库的个人数据结束

    }
  }
})