// miniprogram/pages/hell/hell.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    movies: [
      { url: '../../images/Rotating/news.png' },
      { url: '../../images/Rotating/1.jpg' },
      { url: '../../images/Rotating/2.jpg' }
    ],
  },
})