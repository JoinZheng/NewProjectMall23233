// miniprogram/pages/vx/vx.js
Page({
  data: {
    t: 0,
    sum: {},
    userinfo: {},
    state: {},
    recommend: {},
    openId: "",

    tabs: [{
        name: "推荐",
        id: 0,
        ac: true
      },
      {
        name: "最新",
        id: 1,
        ac: false
      },
      {
        name: "我的",
        id: 2,
        ac: false
      },
    ]
  },

  async onShow() {

    wx.showLoading({
      title: '数据加载中...',
    });

    if(wx.getStorageSync('openId')!=""){
      this.setData({
        openId: wx.getStorageSync('openId').result.openid
      });
    }
    //获取task数据库所有数据
    const db = wx.cloud.database({
      env: "xgj1-056iz"
    })
    //1.获取数据的总个数
    let count = await db.collection('task').count()
    count = count.total
    this.setData({
      sum: count
    })
    //通过for循环多次请求，并且把多次请求的数据放进同一个数组
    let all = []
    for (let i = 0; i < count; i += 20) {
      let list = await db.collection('task').skip(i).get()
      all = all.concat(list.data);
    }
    this.setData({
      arr: all.reverse()
    })

    wx.hideLoading();//隐藏正在加载中
  },

  itemChange(e) { //Tabs传递来的index为t，用来改变"推荐","最新"的状态以及下方显示的内容
    let {
      tabs
    } = this.data;
    const {
      index
    } = e.detail;
    tabs.forEach((v, i) =>
      i === index ? v.ac = true : v.ac = false
    );
    this.setData({
      tabs: tabs,
      t: index
    });
  },

  buttonItem(e) { //点击个人商品以后，获取商品id，然后赋值给全局变量
    // var app = getApp();
    // app.globalData.goodsId = 
    var option = this.data.arr[e.currentTarget.dataset.index]._id
    wx.navigateTo({ //保留当前页面，跳转到应用内的某个页面（最多打开5个页面，之后按钮就没有响应的）后续可以使用wx.navigateBack 可以返回;
      url: "taskContent/taskContent?id="+option
    })
  }
})