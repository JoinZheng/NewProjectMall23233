// miniprogram/pages/task/taskContent/taskContent.js
Page({
  data: {
    openId: "",
    time: "",
    _openid: "", //发布订单的人的openid
    headImg: "https://thirdwx.qlogo.cn/mmopen/vi_32/DYAIOgq83ep7uUDl14MXbERZeMPLWibamk1rZh1BEuA1qVTnTAwk5CZINVGhL1RsqicbqB5uRDF5c7XicYlatj0MQ/132",
    recommend: "",
    taskContent: "",
    taskId: "",
    taskLabel: "",
    taskMoney: "",
    taskTitle: "",
    userName: "",
    taskVx: "",
    acceptUserOpenid: "",
    option: "",
    credibility: {},
    deposit:""
  },

  onLoad: function (option) {

    wx.showLoading({
      title: '数据加载中...',
    });

    if (wx.getStorageSync('openId') != "") {
      this.setData({
        openId: wx.getStorageSync('openId').result.openid
      });
    }
    var that = this;
    this.setData({
      option: option.id
    })
    const db = wx.cloud.database({ // 链接数据表
      env: "xgj1-056iz"
    });
    db.collection('task').where({ //数据查询
      _id: this.data.option //条件
    }).get({
      success: function (taskContent) {
        // res.data 包含该记录的数据
        that.setData({
          headImg: taskContent.data[0].headImg,
          recommend: taskContent.data[0].recommend,
          taskContent: taskContent.data[0].taskContent,
          taskId: taskContent.data[0].taskId,
          taskLabel: taskContent.data[0].taskLabel,
          taskMoney: taskContent.data[0].taskMoney,
          taskTitle: taskContent.data[0].taskTitle,
          userName: taskContent.data[0].userName,
          taskVx: taskContent.data[0].taskVx,
          acceptUserOpenid: taskContent.data[0].acceptUserOpenid,
          _openid: taskContent.data[0]._openid,
          time: taskContent.data[0].time
        })
        db.collection('user').where({ //数据查询
          _openid: that.data._openid //条件
        }).get({
          success: function (taskContent) {
            // res.data 包含该记录的数据
            that.setData({
              credibility: taskContent.data[0].credibility,
              deposit:taskContent.data[0].deposit
            })
          }
        })
      }
    })



    wx.hideLoading(); //隐藏正在加载中
  },

  accept() {
    var that = this;
    const db = wx.cloud.database({ // 链接数据表
      env: "xgj1-056iz"
    });
    db.collection('task').where({ //数据查询
      _id: this.data.option //条件
    }).get({
      success: function (taskContent) {
        // res.data 包含该记录的数据
        that.setData({
          acceptUserOpenid: taskContent.data[0].acceptUserOpenid,
        })
      }
    });
    if (this.data.acceptUserOpenid != "") { //如果在同一页面已经被别人接取，那么就提示
      wx.showModal({
        title: "接取失败", // 提示的标题
        content: "手慢了哦，单子在几秒前就被别人接走啦！", // 提示的内容
        showCancel: true, // 是否显示取消按钮，默认true
        cancelColor: "#000000", // 取消按钮的文字颜色，必须是16进制格式的颜色字符串
        confirmText: "确认", // 确认按钮的文字，最多4个字符
        confirmColor: "#576B95", // 确认按钮的文字颜色，必须是 16 进制格式的颜色字符串
        complete: function () {
          // console.log("接口调用结束的回调函数（调用成功、失败都会执行）");
          wx.navigateBack({
            delta: 1
          })
        }
      })
    } else if (this.data._openid == this.data.openId) { //如果是本人接单，提示错误
      
      wx.showToast({
        title: "纺院社区：不可接自己单子", // 提示的内容
        icon: "none", // 图标，默认success
        image: "", // 自定义图标的本地路径，image 的优先级高于 icon
        duration: 1500, // 提示的延迟时间，默认1500
        mask: false, // 是否显示透明蒙层，防止触摸穿透
      })

    } else {

      wx.showLoading({
        title: '数据加载中...',
      });

      const db = wx.cloud.database({
        env: "xgj1-056iz"
      });
      db.collection('task').where({
        _id: that.data.option //条件
      }).update({
        // data 字段表示需新增的 JSON 数据
        data: {
          acceptUserOpenid: that.data.openId,
        },
      })

      wx.hideLoading(); //隐藏正在加载中

      wx.showModal({
        title: "接单成功", // 提示的标题
        content: "您已成功接单,成功获取商家的联系方式，快去与商家联络完成订单吧！", // 提示的内容
        showCancel: true, // 是否显示取消按钮，默认true
        cancelColor: "#000000", // 取消按钮的文字颜色，必须是16进制格式的颜色字符串
        confirmText: "确定", // 确认按钮的文字，最多4个字符
        confirmColor: "#576B95", // 确认按钮的文字颜色，必须是 16 进制格式的颜色字符串
        complete: function () {
          // console.log("接口调用结束的回调函数（调用成功、失败都会执行）");

        }
      })
    }
  },

})